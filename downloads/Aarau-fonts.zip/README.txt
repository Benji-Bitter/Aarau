Aarau 0.1 by Benjamin Miles
Install one font format to avoid duplicate families.
Variable axis: wght 100–900. Development release.
Contact: benmilespersonal@gmail.com / +61 410 047 269
See LICENSE.txt for usage and redistribution terms.
